
import { GoogleGenAI } from "@google/genai";

export const getDiagnosis = async (input: string) => {
  try {
    // Untuk Manual Deploy, API_KEY harus di-inject saat proses build lokal.
    const apiKey = process.env.API_KEY;
    
    if (!apiKey) {
      console.error("API_KEY tidak ditemukan. Pastikan Anda melakukan build dengan API_KEY yang benar.");
      return { 
        error: "Sistem belum terkonfigurasi. Silakan hubungi admin atau cek pengaturan Build Anda." 
      };
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: input,
      config: {
        systemInstruction: "Kamu adalah Pakar Strategi Bisnis UMKM Indonesia. Berikan diagnosa tajam (maks 3 paragraf) dan 1 langkah nyata yang bisa dilakukan besok pagi. Gunakan bahasa santai tapi profesional.",
      },
    });

    return {
      result: response.text
    };
  } catch (e: any) {
    console.error("Gemini API Error:", e);
    return { 
      error: "Koneksi ke AI sedang padat. Tunggu 10 detik lalu coba lagi ya." 
    };
  }
};
