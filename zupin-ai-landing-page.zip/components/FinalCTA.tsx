
import React from 'react';

const FinalCTA: React.FC = () => {
  return (
    <section className="py-24 md:py-40 px-6 bg-black text-white text-center relative overflow-hidden">
      <div className="absolute inset-0 bg-amber-500/5 pointer-events-none"></div>
      <div className="max-w-4xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-8xl font-black mb-12 md:mb-16 leading-[1.1] md:leading-[0.9] tracking-tighter uppercase">
          Jualan Itu Capek<br /> <span className="text-gray-800">Kalau Salah Arah</span>
        </h2>
        <a 
          href="https://lynk.id/tegu03" 
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block w-full md:w-auto px-10 py-5 md:px-14 md:py-7 bg-white text-black rounded-full text-lg md:text-2xl font-black uppercase tracking-tighter hover:bg-amber-500 hover:text-white transition-all transform hover:scale-105 shadow-[0_20px_80px_rgba(255,255,255,0.1)] mb-10"
        >
          Stop Jualan Pakai Feeling
        </a>
        <p className="text-amber-500 font-black uppercase tracking-[0.2em] md:tracking-[0.3em] text-[10px] md:text-xs">
          Mulai dari memahami akar masalahmu sekarang.
        </p>
      </div>
    </section>
  );
};

export default FinalCTA;
