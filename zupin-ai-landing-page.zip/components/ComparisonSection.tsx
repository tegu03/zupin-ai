
import React from 'react';

const ComparisonSection: React.FC = () => {
  const cases = [
    {
      situation: "Chat ada tapi gak closing",
      before: "Terus-terusan promosi atau banting harga tanpa tahu kenapa mereka ragu.",
      after: "Paham kalau cara jawab chat yang bikin pembeli tidak percaya."
    },
    {
      situation: "Toko sepi total",
      before: "Posting asal-asalan setiap hari sambil berharap keajaiban datang.",
      after: "Fokus benerin profil dan kata kunci yang dicari calon pembeli."
    },
    {
      situation: "Mental sudah capek",
      before: "Bingung mulai dari mana, akhirnya cuma scroll hp and gak ngapa-ngapain.",
      after: "Tau persis harus benerin 1 hal kecil yang paling penting pagi besok."
    }
  ];

  return (
    <section className="py-32 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-center text-3xl md:text-5xl lg:text-6xl font-black mb-24 text-white uppercase tracking-tighter leading-tight">
          Sebelum & <span className="text-gold-hook italic pr-4">Sesudah pakai</span> ZUPIN - AI
        </h2>
        
        <div className="space-y-10">
          {cases.map((item, index) => (
            <div key={index} className="grid md:grid-cols-12 gap-8 items-stretch p-8 rounded-[40px] bg-white/5 border border-white/5">
              <div className="md:col-span-4 flex flex-col justify-center">
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-amber-500 block mb-3">Kasus Nyata</span>
                <h3 className="text-2xl font-black text-white leading-tight uppercase tracking-tight">{item.situation}</h3>
              </div>
              <div className="md:col-span-4 bg-red-950/30 p-8 rounded-3xl border border-red-900/30 flex flex-col justify-center">
                <span className="text-xs font-black text-red-500 uppercase mb-4 tracking-widest">⚠️ Sebelum</span>
                <p className="text-red-100/70 italic font-medium">"{item.before}"</p>
              </div>
              <div className="md:col-span-4 bg-emerald-950/30 p-8 rounded-3xl border border-emerald-900/30 flex flex-col justify-center">
                <span className="text-xs font-black text-emerald-400 uppercase mb-4 tracking-widest">✨ Sesudah</span>
                <p className="text-emerald-50 font-bold">"{item.after}"</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ComparisonSection;
