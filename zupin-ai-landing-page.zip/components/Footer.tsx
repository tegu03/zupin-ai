
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="py-16 bg-black border-t border-white/5 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-10">
        <div className="text-center md:text-left">
          <span className="text-2xl font-black tracking-tighter text-white uppercase italic">ZUPIN<span className="text-amber-500">.AI</span></span>
          <p className="text-[10px] text-gray-600 font-bold uppercase tracking-widest mt-2">© 2024 ZUPIN-AI. Komitmen Memajukan UMKM Indonesia.</p>
        </div>
        <div className="flex gap-10 text-[10px] font-black uppercase tracking-widest text-gray-500">
          <a href="#" className="hover:text-amber-500 transition-colors">Kebijakan Privasi</a>
          <a href="#" className="hover:text-amber-500 transition-colors">Syarat Ketentuan</a>
          <a href="#" className="hover:text-amber-500 transition-colors">Kontak Kami</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
