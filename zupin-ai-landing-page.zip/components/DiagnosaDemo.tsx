
import React, { useState, useEffect } from 'react';
import { getDiagnosis } from '../services/geminiService';

const DiagnosaDemo: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [hasUsedFreeAttempt, setHasUsedFreeAttempt] = useState(false);

  useEffect(() => {
    const used = localStorage.getItem('zupin_used');
    if (used === 'true') {
      setHasUsedFreeAttempt(true);
      setResult(localStorage.getItem('zupin_res'));
    }
  }, []);

  const handleCek = async () => {
    if (!input.trim()) {
      setStatusMessage("⚠️ Tuliskan dulu masalah jualanmu di atas.");
      return;
    }

    setLoading(true);
    setStatusMessage("⏳ Sedang menganalisa... Mohon tunggu.");
    setResult(null);

    try {
      const data = await getDiagnosis(input);

      if (data.error) {
        setStatusMessage(`❌ ${data.error}`);
        setLoading(false);
        return;
      }

      if (data.result) {
        setResult(data.result);
        setStatusMessage(null);
        localStorage.setItem('zupin_used', 'true');
        localStorage.setItem('zupin_res', data.result);
        setHasUsedFreeAttempt(true);
      }
    } catch (err) {
      setStatusMessage("❌ Terjadi kesalahan jaringan. Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="diagnosa-demo" className="py-20 px-4 relative">
      <div className="max-w-4xl mx-auto">
        <div className="bg-black border border-white/10 rounded-[40px] p-8 md:p-16 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-amber-500 opacity-30"></div>
          
          <div className="text-center mb-10">
            <h3 className="text-2xl md:text-4xl font-black text-white uppercase italic">Diagnosa <span className="text-amber-500">Gratis</span></h3>
            <p className="text-gray-500 text-sm mt-2">Dapatkan jawaban kenapa jualanmu sepi langsung dari AI.</p>
          </div>
          
          {!hasUsedFreeAttempt ? (
            <div className="space-y-6">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Contoh: 'Saya jualan hijab di Shopee, traffic banyak tapi yang beli dikit banget...'"
                className="w-full h-44 p-6 rounded-3xl bg-white/5 border border-white/10 focus:border-amber-500 outline-none text-white text-lg transition-all resize-none"
              />
              
              <button
                onClick={handleCek}
                disabled={loading}
                className="w-full py-5 gold-button-hook text-white rounded-full font-black text-xl uppercase tracking-widest disabled:opacity-50"
              >
                {loading ? "PROSES ANALISA..." : "CEK MASALAH SAYA"}
              </button>
            </div>
          ) : (
            <div className="text-center p-8 bg-amber-500/5 border border-amber-500/20 rounded-3xl">
              <p className="text-amber-500 font-bold mb-4 italic">Kesempatan diagnosa gratis Anda sudah digunakan.</p>
              <a href="#paket" className="text-white font-black underline uppercase tracking-widest hover:text-amber-500 transition-colors">Dapatkan Akses Tanpa Batas Di Sini</a>
            </div>
          )}

          <div className="mt-8">
            {statusMessage && (
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
                <p className="text-amber-500 text-sm font-medium">{statusMessage}</p>
              </div>
            )}

            {result && (
              <div className="mt-6 p-8 bg-white/5 border-l-4 border-amber-500 rounded-2xl text-white leading-relaxed whitespace-pre-wrap font-medium animate-in fade-in slide-in-from-bottom-4">
                {result}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default DiagnosaDemo;
