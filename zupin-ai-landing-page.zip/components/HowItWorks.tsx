
import React from 'react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      step: "01",
      title: "Ceritakan Kondisimu",
      desc: "Kamu ceritakan apa yang sedang terjadi di jualanmu saat ini secara jujur."
    },
    {
      step: "02",
      title: "Temukan Masalah Utama",
      desc: "ZUPIN-AI bantu menemukan 1 akar masalah yang selama ini menghambatmu."
    },
    {
      step: "03",
      title: "Langkah Besok",
      desc: "Kamu dapat 1–3 langkah kecil yang realistis untuk langsung diperbaiki besok."
    }
  ];

  return (
    <section id="cara-kerja" className="py-32 px-6 bg-[#0a0a0a] relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-amber-500/5 blur-[120px] pointer-events-none"></div>
      
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="mb-24 text-center">
          <h2 className="text-4xl md:text-5xl font-black mb-6 text-white uppercase tracking-tighter">ZUPIN-AI Bukan AI Biasa</h2>
          <p className="text-amber-500/80 text-xl font-bold italic">ZUPIN-AI tidak memberi 100 tips. ZUPIN-AI mulai dari diagnosa.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-16">
          {steps.map((item, index) => (
            <div key={index} className="relative group">
              <div className="text-7xl font-black text-white/5 group-hover:text-amber-500/10 transition-colors absolute -top-10 -left-4">
                {item.step}
              </div>
              <div className="relative z-10">
                <h3 className="text-2xl font-black mb-4 text-white uppercase tracking-tight">{item.title}</h3>
                <p className="text-gray-400 leading-relaxed text-lg font-medium">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-24 p-12 rounded-[40px] bg-white text-black text-center shadow-[0_20px_60px_rgba(255,255,255,0.1)]">
          <p className="text-2xl font-black tracking-tight uppercase">
            Tidak ribet. Tidak menggurui. <span className="text-amber-600">Fokus ke besok, bukan teori panjang.</span>
          </p>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
