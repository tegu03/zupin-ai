
import React, { useState, useEffect } from 'react';

const CountdownBanner: React.FC = () => {
  const targetDate = new Date('2025-02-15T00:00:00').getTime();
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    isExpired: false
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft(prev => ({ ...prev, isExpired: true }));
        clearInterval(timer);
      } else {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
          isExpired: false
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  if (timeLeft.isExpired) return null;

  const TimeUnit = ({ value, label }: { value: number, label: string }) => (
    <div className="flex flex-col items-center">
      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl md:rounded-2xl w-14 h-14 md:w-20 md:h-20 flex items-center justify-center mb-2">
        <span className="text-2xl md:text-4xl font-black text-amber-500 tabular-nums">
          {value.toString().padStart(2, '0')}
        </span>
      </div>
      <span className="text-[8px] md:text-[10px] font-black uppercase tracking-widest text-gray-500">{label}</span>
    </div>
  );

  return (
    <div className="py-12 md:py-20 px-6 bg-[#080808] border-t border-white/5">
      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-block px-4 py-1.5 mb-8 rounded-full bg-amber-500/10 border border-amber-500/20">
          <p className="text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-amber-500">
            ⚠️ Penawaran Terbatas
          </p>
        </div>
        
        <h3 className="text-2xl md:text-4xl font-black text-white uppercase tracking-tighter mb-10 leading-tight">
          Harga Kembali Normal <br className="md:hidden" /> Pada <span className="text-amber-500">15 Februari 2025</span>
        </h3>

        <div className="flex justify-center items-center gap-3 md:gap-6">
          <TimeUnit value={timeLeft.days} label="Hari" />
          <div className="text-2xl md:text-4xl font-black text-white/20 mb-6">:</div>
          <TimeUnit value={timeLeft.hours} label="Jam" />
          <div className="text-2xl md:text-4xl font-black text-white/20 mb-6">:</div>
          <TimeUnit value={timeLeft.minutes} label="Menit" />
          <div className="text-2xl md:text-4xl font-black text-white/20 mb-6">:</div>
          <TimeUnit value={timeLeft.seconds} label="Detik" />
        </div>
        
        <p className="mt-12 text-gray-500 text-xs md:text-sm font-bold uppercase tracking-widest animate-pulse">
          Segera amankan slot diagnosa anda sekarang
        </p>
      </div>
    </div>
  );
};

export default CountdownBanner;
