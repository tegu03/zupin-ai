
import React from 'react';

const Navbar: React.FC = () => {
  return (
    <nav className="fixed top-0 left-0 w-full bg-black/60 backdrop-blur-2xl z-50 border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 md:h-20 flex items-center justify-between">
        <div className="flex items-center gap-2 group cursor-pointer">
          <span className="text-xl md:text-2xl font-black tracking-tighter italic text-white group-hover:text-amber-500 transition-colors">
            ZUPIN<span className="text-amber-500">.AI</span>
          </span>
        </div>
        <div className="hidden md:flex gap-10 text-xs font-bold uppercase tracking-widest text-gray-400">
          <a href="#masalah" className="hover:text-amber-500 transition-colors">Masalah</a>
          <a href="#cara-kerja" className="hover:text-amber-500 transition-colors">Cara Kerja</a>
          <a href="#paket" className="hover:text-amber-500 transition-colors">Pilihan</a>
        </div>
        <a 
          href="#diagnosa-demo" 
          className="text-[10px] md:text-xs font-black uppercase tracking-widest px-4 py-2.5 md:px-6 md:py-3 gold-button-hook text-white rounded-full shimmer-wrapper"
        >
          Diagnosa
        </a>
      </div>
    </nav>
  );
};

export default Navbar;
