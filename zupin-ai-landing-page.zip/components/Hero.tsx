
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="pt-32 pb-20 md:pt-64 md:pb-40 px-6 relative overflow-hidden">
      {/* Light Hooks */}
      <div className="light-aura top-[-10%] left-[-10%] opacity-50"></div>
      <div className="light-aura bottom-[-10%] right-[-10%]" style={{ animationDelay: '4s' }}></div>
      
      <div className="max-w-5xl mx-auto text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 md:mb-10 bg-white/5 border border-white/10 rounded-full text-[9px] md:text-[10px] font-black tracking-[0.2em] md:tracking-[0.3em] uppercase text-amber-500 animate-pulse">
          <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
          Partner Strategis UMKM Indonesia
        </div>
        
        <h1 className="text-3xl sm:text-4xl md:text-7xl lg:text-8xl font-black tracking-tighter leading-[1.1] md:leading-[0.95] mb-8 md:mb-10 text-white">
          Sudah Capek Jualan… <br className="hidden md:block" />
          Tapi Masih Bingung <br />
          <span className="text-gold-hook italic pr-4">Apa yang Perlu Diperbaiki?</span>
        </h1>
        
        <p className="text-base md:text-2xl text-gray-400 mb-10 md:mb-16 max-w-2xl mx-auto leading-relaxed font-light">
          ZUPIN-AI mendiagnosa titik macet bisnis Anda dan memberikan panduan praktis yang bisa dieksekusi <span className="text-white font-bold text-lg md:text-2xl">BESOK</span> pagi.
        </p>
        
        <div className="flex flex-col items-center gap-6 md:gap-8">
          <a 
            href="https://lynk.id/tegu03" 
            target="_blank"
            rel="noopener noreferrer"
            className="group relative w-full md:w-auto px-8 py-4 md:px-12 md:py-6 bg-white text-black rounded-full text-lg md:text-xl font-black uppercase tracking-tighter overflow-hidden transition-all hover:bg-amber-500 hover:text-white shadow-[0_20px_50px_rgba(255,255,255,0.1)] hover:shadow-amber-500/40 text-center"
          >
            <span className="relative z-10">Stop Jualan Pakai Feeling</span>
          </a>
          
          <div className="flex flex-wrap justify-center items-center gap-x-4 gap-y-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
            <span className="flex items-center gap-1"><svg className="w-3.5 h-3.5 text-amber-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg> Tanpa Dashboard</span>
            <span className="hidden sm:block w-1 h-1 bg-gray-700 rounded-full"></span>
            <span className="flex items-center gap-1"><svg className="w-3.5 h-3.5 text-amber-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg> Langsung Solusi</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
