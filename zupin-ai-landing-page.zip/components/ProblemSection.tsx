
import React from 'react';

const ProblemSection: React.FC = () => {
  const problems = [
    { text: "Sudah posting, tapi sepi", icon: "📱", color: "from-amber-500/20" },
    { text: "Chat ada, tapi gak beli", icon: "💬", color: "from-amber-600/20" },
    { text: "Capek promo, tapi bingung", icon: "😫", color: "from-amber-700/20" },
    { text: "Akhirnya cuma nebak-nebak", icon: "🎲", color: "from-amber-400/20" }
  ];

  return (
    <section id="masalah" className="py-24 md:py-40 bg-black text-white px-4 md:px-6 overflow-hidden relative">
      <div className="light-aura opacity-20 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[800px] h-[300px] md:h-[800px]"></div>
      
      <div className="max-w-6xl mx-auto relative z-10">
        <h2 className="text-center text-3xl md:text-7xl font-black mb-16 md:mb-24 leading-tight md:leading-none tracking-tighter uppercase">
          Masalah UMKM <br /> <span className="text-gray-700">Bukan Kurang Usaha</span>
        </h2>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-20 md:mb-32">
          {problems.map((problem, index) => (
            <div key={index} className="group p-6 md:p-10 rounded-2xl md:rounded-[40px] bg-white/5 border border-white/5 hover:border-amber-500/30 transition-all hover:-translate-y-2 relative overflow-hidden h-48 md:h-72 flex flex-col justify-end">
              <div className={`absolute inset-0 bg-gradient-to-t ${problem.color} to-transparent opacity-0 group-hover:opacity-100 transition-opacity`}></div>
              <div className="relative z-10">
                <div className="text-3xl md:text-5xl mb-4 md:mb-6 grayscale group-hover:grayscale-0 transition-all duration-500">{problem.icon}</div>
                <p className="text-sm md:text-lg text-gray-300 font-bold leading-tight group-hover:text-white transition-colors">{problem.text}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center max-w-4xl mx-auto border-t border-white/5 pt-16 md:pt-24">
          <p className="text-xl md:text-5xl text-gray-500 leading-tight italic font-light">
            "Masalahnya bukan di kamu. Masalahnya kamu gak punya alat untuk <span className="text-gold-hook font-black tracking-tighter not-italic uppercase">DIAGNOSA</span>."
          </p>
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
