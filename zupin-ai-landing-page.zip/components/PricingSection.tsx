
import React, { useState, useEffect } from 'react';

const PricingSection: React.FC = () => {
  const targetDate = new Date('2025-02-15T00:00:00').getTime();
  const [timeLeft, setTimeLeft] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0,
    isExpired: false
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft(prev => ({ ...prev, isExpired: true }));
        clearInterval(timer);
      } else {
        const totalHours = Math.floor(difference / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        
        setTimeLeft({
          hours: totalHours,
          minutes: minutes,
          seconds: seconds,
          isExpired: false
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  const packages = [
    {
      title: "Zupin Basic",
      priceOriginal: "150.000",
      priceDiscount: "19.500",
      desc: "Kejelasan dasar untuk kamu yang baru mulai sadar ada yang salah.",
      features: [
        "Diagnosa 1 masalah utama",
        "1 langkah kecil untuk BESOK",
        "Bahasa sederhana, tanpa teori"
      ],
      cta: "Coba Sekarang",
      link: "https://lynk.id/tegu03/e6z00yl23e83",
      highlight: false
    },
    {
      title: "Zupin Pro",
      priceOriginal: "350.000",
      priceDiscount: "29.000",
      desc: "Perbaikan sistematis untuk yang sudah jualan tapi stagnan.",
      features: [
        "Diagnosa lebih dalam & profil",
        "2–3 tindakan konkret per hari",
        "Contoh teks chat atau caption",
        "Analisa titik macet funnel"
      ],
      cta: "Mulai Lebih Serius",
      link: "https://lynk.id/tegu03/47o0011vogew",
      highlight: true
    },
    {
      title: "Zupin Expert",
      priceOriginal: "449.000",
      priceDiscount: "39.000",
      desc: "Pendampingan berpikir harian untuk bisnis yang ingin naik kelas.",
      features: [
        "Diagnosa menyeluruh mingguan",
        "Prioritas perbaikan detail",
        "Arah harian & mingguan",
        "Pendamping berpikir (Partner)"
      ],
      cta: "Saya Butuh Partner",
      link: "https://lynk.id/tegu03/x53eemvy3qle",
      highlight: false
    }
  ];

  return (
    <section id="paket" className="py-24 md:py-40 px-4 md:px-6 bg-[#080808]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 md:mb-32">
            <h2 className="text-3xl md:text-7xl font-black mb-6 md:mb-8 text-white tracking-tighter leading-none uppercase italic">Investasi Ke <br /> <span className="text-gold-hook pr-4">Arah Yang Benar</span></h2>
            <p className="text-gray-500 font-bold uppercase tracking-[0.2em] md:tracking-[0.3em] text-[10px] md:text-xs">Pilih paket pendampingan berpikir Anda</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6 md:gap-10 items-stretch mb-16 md:mb-24">
          {packages.map((pkg, index) => (
            <div 
              key={index} 
              className={`p-8 md:p-12 rounded-[40px] md:rounded-[56px] flex flex-col transition-all duration-700 hover:scale-[1.02] ${
                pkg.highlight 
                  ? 'bg-amber-500 text-black shadow-[0_40px_100px_-20px_rgba(217,119,6,0.4)] z-10 relative overflow-hidden' 
                  : 'bg-white/5 border border-white/5 hover:border-amber-500/20'
              }`}
            >
              {pkg.highlight && <div className="absolute top-0 right-0 w-40 h-40 bg-white/20 blur-[60px] -mr-20 -mt-20"></div>}
              
              <div className="flex flex-col mb-8 md:mb-10 relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <h3 className={`text-2xl md:text-3xl font-black uppercase tracking-tighter ${pkg.highlight ? 'text-black' : 'text-white'}`}>{pkg.title}</h3>
                  {pkg.highlight && <span className="px-3 py-1 bg-black text-white text-[9px] font-black uppercase tracking-widest rounded-full">Laris</span>}
                </div>
                
                <div>
                  <span className={`text-xs md:text-sm font-bold line-through opacity-50 mr-2 ${pkg.highlight ? 'text-black' : 'text-gray-400'}`}>
                    Rp{pkg.priceOriginal}
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className={`text-3xl md:text-4xl font-black ${pkg.highlight ? 'text-black' : 'text-amber-500'}`}>
                      Rp{pkg.priceDiscount}
                    </span>
                    <span className={`text-[9px] md:text-[10px] font-bold uppercase tracking-widest opacity-80 ${pkg.highlight ? 'text-black' : 'text-gray-300'}`}>
                      / Selamanya
                    </span>
                  </div>
                </div>
              </div>
              
              <p className={`${pkg.highlight ? 'text-black/80' : 'text-gray-500'} text-xs md:text-sm mb-10 md:mb-12 font-bold leading-relaxed relative z-10`}>{pkg.desc}</p>
              
              <ul className="space-y-4 md:space-y-6 mb-12 md:mb-16 flex-grow relative z-10">
                {pkg.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-3 md:gap-4 text-xs md:text-sm font-bold uppercase tracking-tight">
                    <svg className={`w-4 h-4 md:w-5 md:h-5 flex-shrink-0 mt-0.5 ${pkg.highlight ? 'text-black' : 'text-amber-500'}`} fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                    </svg>
                    <span className={pkg.highlight ? 'text-black' : 'text-gray-300'}>{f}</span>
                  </li>
                ))}
              </ul>

              <a 
                href={pkg.link}
                target="_blank"
                rel="noopener noreferrer"
                className={`w-full py-4 md:py-6 rounded-full font-black text-base md:text-lg text-center transition-all active:scale-95 relative z-10 uppercase tracking-widest ${
                  pkg.highlight ? 'bg-black text-white hover:bg-zinc-900 shadow-2xl' : 'bg-white text-black hover:bg-amber-500 hover:text-white'
                }`}
              >
                {pkg.cta}
              </a>
            </div>
          ))}
        </div>

        {/* New Countdown at the bottom of the grid */}
        {!timeLeft.isExpired && (
          <div className="flex flex-col items-center justify-center p-8 md:p-12 bg-white/5 border border-white/10 rounded-[32px] md:rounded-[48px] animate-pulse">
            <span className="text-[10px] md:text-xs font-black uppercase tracking-[0.3em] text-amber-500 mb-6">
              ⚡ Promo Berakhir Dalam:
            </span>
            <div className="flex items-center gap-4 md:gap-8">
              <div className="flex flex-col items-center">
                <span className="text-3xl md:text-6xl font-black text-white tabular-nums">{timeLeft.hours.toString().padStart(2, '0')}</span>
                <span className="text-[8px] md:text-[10px] font-bold uppercase tracking-widest text-gray-500 mt-2">Jam</span>
              </div>
              <span className="text-2xl md:text-4xl font-black text-white/20">:</span>
              <div className="flex flex-col items-center">
                <span className="text-3xl md:text-6xl font-black text-white tabular-nums">{timeLeft.minutes.toString().padStart(2, '0')}</span>
                <span className="text-[8px] md:text-[10px] font-bold uppercase tracking-widest text-gray-500 mt-2">Menit</span>
              </div>
              <span className="text-2xl md:text-4xl font-black text-white/20">:</span>
              <div className="flex flex-col items-center">
                <span className="text-3xl md:text-6xl font-black text-white tabular-nums">{timeLeft.seconds.toString().padStart(2, '0')}</span>
                <span className="text-[8px] md:text-[10px] font-bold uppercase tracking-widest text-gray-500 mt-2">Detik</span>
              </div>
            </div>
            <p className="mt-8 text-gray-400 text-[9px] md:text-xs font-bold uppercase tracking-widest">
              Harga akan kembali normal pada 15 Februari 2025
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default PricingSection;
