
import React from 'react';

const DisclaimerSection: React.FC = () => {
  return (
    <section className="py-32 px-6 bg-[#080808]">
      <div className="max-w-3xl mx-auto text-center border-t border-white/5 pt-20">
        <p className="text-2xl text-gray-300 mb-10 leading-relaxed font-light">
          ZUPIN-AI tidak menjanjikan omzet. <br />
          ZUPIN-AI membantu kamu <span className="text-white font-bold">berhenti salah fokus.</span>
        </p>
        <div className="inline-block px-8 py-4 rounded-2xl bg-white/5 border border-white/10">
          <p className="text-sm text-amber-500/60 font-black uppercase tracking-widest italic">
            Kalau kamu ingin keajaiban instan, <br />
            ZUPIN-AI bukan untukmu.
          </p>
        </div>
      </div>
    </section>
  );
};

export default DisclaimerSection;
